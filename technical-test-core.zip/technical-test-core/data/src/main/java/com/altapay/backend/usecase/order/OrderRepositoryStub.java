package com.altapay.backend.usecase.order;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class OrderRepositoryStub implements OrderRepository {

  public Optional<Order> find(String orderId) {
    List<OrderLine> orderLines = new ArrayList<OrderLine>();
    orderLines.add(getOrderLine("1", "Keyboard", 1));

    return Optional.of(new Order(orderId, UUID.randomUUID().toString(), orderLines));
  }

  private OrderLine getOrderLine(String productId, String name, int quantity) {
    Product product = new Product(productId, name);

    return new OrderLine(product, quantity);
  }
}
