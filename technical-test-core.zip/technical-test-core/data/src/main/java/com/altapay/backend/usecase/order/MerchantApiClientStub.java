package com.altapay.backend.usecase.order;

import com.altapay.backend.usecase.order.exceptions.MerchantApiServiceException;
import com.altapay.utils.HttpUtil;
import com.altapay.utils.XpathUtil;

public class MerchantApiClientStub implements MerchantApiClient {

  private final HttpUtil httpUtil = new HttpUtil();
  private final XpathUtil xpathUtil = new XpathUtil();

  public CapturePaymentResult capturePayment(Order order) throws MerchantApiServiceException {
    // We don't need to implement this, write the rest of the code as if this has been implemented by use of the httpUtil and the xpathUtil
    return null;
  }

  public CancelPaymentResult cancelPayment(Order order) throws MerchantApiServiceException {
    // We don't need to implement this, write the rest of the code as if this has been implemented by use of the httpUtil and the xpathUtil
    return null;
  }
}
