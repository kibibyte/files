package com.altapay.backend.usecase.order;

import java.util.Optional;

public class InventoryRepositoryStub implements InventoryRepository {

  public Optional<InventoryItem> find(String productId) {
    // We dont need to implement this, write the rest of the code as if this has been implemented
    return null;
  }

  public void update(InventoryItem inventoryItem) {
    // We dont need to implement this, write the rest of the code as if this has been implemented
  }
}
