package com.altapay.utils;

/**
 * We don't need to implement this, write the rest of the code as if this just works
 */
public class HttpParamList {

}
