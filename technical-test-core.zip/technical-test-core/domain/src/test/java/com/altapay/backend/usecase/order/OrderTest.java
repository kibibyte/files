package com.altapay.backend.usecase.order;

import static java.util.Collections.emptyList;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;

import org.junit.jupiter.api.Test;

public class OrderTest {

  private static final String ORDER_ID = "orderId";
  private static final String PAYMENT_ID = "paymentId";

  @Test
  public void shouldCreateShoOrder() {
    //given
    Product product = new Product("productId", "productName");
    OrderLine orderLine = new OrderLine(product, 1);
    List<OrderLine> orderLines = List.of(orderLine);

    //when
    assertDoesNotThrow(() -> new Order(ORDER_ID, PAYMENT_ID, orderLines));
  }

  @Test
  public void shouldNotCreateShoOrder_whenPaymentIdIsEmpty() {
    //given
    Product product = new Product("productId", "productName");
    OrderLine orderLine = new OrderLine(product, 1);
    List<OrderLine> orderLines = List.of(orderLine);

    //when
    assertThrows(IllegalArgumentException.class, () -> new Order(ORDER_ID, "", orderLines));
  }

  @Test
  public void shouldNotCreateShoOrder_whenOrderLinesIsEmpty() {
    //when
    assertThrows(IllegalArgumentException.class, () -> new Order(ORDER_ID, PAYMENT_ID, emptyList()));
  }
}
