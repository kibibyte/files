package com.altapay.backend.usecase.order.capture;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.altapay.backend.usecase.order.InventoryService;
import com.altapay.backend.usecase.order.MerchantService;
import com.altapay.backend.usecase.order.Order;
import com.altapay.backend.usecase.order.OrderLine;
import com.altapay.backend.usecase.order.OrderRepository;
import com.altapay.backend.usecase.order.Product;
import com.altapay.backend.usecase.order.exceptions.InsufficientStockForProductException;
import com.altapay.backend.usecase.order.exceptions.MerchantApiServiceException;
import com.altapay.backend.usecase.order.exceptions.OrderException;

public class CaptureOrderServiceTest {

  private static final String ORDER_ID = "orderId";
  private static final String PAYMENT_ID = "paymentId";

  @Mock
  OrderRepository orderRepository;
  @Mock
  InventoryService inventoryService;
  @Mock
  MerchantService merchantService;

  // The object to be tested
  private CaptureOrderService orderService;

  @BeforeEach
  public void setUp() throws Exception {
    MockitoAnnotations.openMocks(this);
    orderService = new CaptureOrderService(orderRepository, inventoryService, merchantService);
  }

  @Test
  public void shouldCaptureOrder() {
    //given
    Product product = new Product("productId", "productName");
    OrderLine orderLine = new OrderLine(product, 1);
    Order order = new Order(ORDER_ID, PAYMENT_ID, List.of(orderLine));
    when(orderRepository.find(ORDER_ID)).thenReturn(Optional.of(order));
    when(inventoryService.checkStock(orderLine.getProduct(), orderLine.getQuantity())).thenReturn(true);

    //when
    orderService.captureOrder(ORDER_ID);

    //then
    verify(orderRepository, times(1)).find(ORDER_ID);
    verify(merchantService, times(1)).capturePayment(order);
    verify(inventoryService, times(1)).checkStock(orderLine.getProduct(), orderLine.getQuantity());
    verify(inventoryService, times(1)).take(orderLine.getProduct(), orderLine.getQuantity());
    verify(inventoryService, times(0)).release(orderLine.getProduct(), orderLine.getQuantity());
  }

  @Test
  public void shouldNotCaptureOrder_whenProductsNotInStock() {
    //given
    Order order = validShopOrder();
    when(orderRepository.find(any())).thenReturn(Optional.of(order));
    when(inventoryService.checkStock(any(), anyInt())).thenReturn(false);

    //when
    assertThrows(InsufficientStockForProductException.class, () -> orderService.captureOrder(any()));

    //then
    verify(orderRepository, times(1)).find(any());
    verify(merchantService, times(0)).capturePayment(any());
    verify(inventoryService, times(1)).checkStock(any(), anyInt());
    verify(inventoryService, times(0)).take(any(), anyInt());
    verify(inventoryService, times(0)).release(any(), anyInt());
  }

  @Test
  public void shouldNotCaptureOrder_whenMerchantApiFails() {
    //given
    Order order = validShopOrder();
    when(orderRepository.find(any())).thenReturn(Optional.of(order));
    when(inventoryService.checkStock(any(), anyInt())).thenReturn(true);
    when(merchantService.capturePayment(any())).thenThrow(new MerchantApiServiceException("Merchant error"));

    //when
    assertThrows(OrderException.class, () -> orderService.captureOrder(any()));

    //then
    verify(orderRepository, times(1)).find(any());
    verify(merchantService, times(1)).capturePayment(any());
    verify(inventoryService, times(1)).checkStock(any(), anyInt());
    verify(inventoryService, times(0)).take(any(), anyInt());
    verify(inventoryService, times(0)).release(any(), anyInt());
  }

  private Order validShopOrder() {
    Product product = new Product("productId", "productName");
    OrderLine orderLine = new OrderLine(product, 1);

    return new Order(ORDER_ID, PAYMENT_ID, List.of(orderLine));
  }
}
