package com.altapay.backend.usecase.order.cancel;

import com.altapay.backend.exceptions.EntityNotFoundException;
import com.altapay.backend.usecase.order.InventoryService;
import com.altapay.backend.usecase.order.MerchantService;
import com.altapay.backend.usecase.order.Order;
import com.altapay.backend.usecase.order.OrderRepository;
import com.altapay.backend.usecase.order.exceptions.OrderException;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class CancelOrderService {

  private final OrderRepository orderRepository;
  private final InventoryService inventoryService;
  private final MerchantService merchantService;

  public void cancelOrder(String orderId) {
    Order order = getOrder(orderId);
    try {
      merchantService.cancelPayment(order);
      releaseToInventory(order);
    } catch (Exception e) {
      throw new OrderException("Order cannot be cancelled");
    }
  }

  private void releaseToInventory(Order order) {
    order.getOrderLines().forEach(line -> inventoryService.release(line.getProduct(), line.getQuantity()));
  }

  private Order getOrder(String orderId) {
    return orderRepository.find(orderId).orElseThrow(() -> new EntityNotFoundException("Order not found"));
  }
}
