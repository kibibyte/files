package com.altapay.backend.usecase.order;

import java.util.Optional;

public interface InventoryRepository {

  Optional<InventoryItem> find(String productId);

  void update(InventoryItem inventoryItem);
}
