package com.altapay.backend.usecase.order.exceptions;

import com.altapay.backend.exceptions.DomainException;

public class InsufficientStockForProductException extends DomainException {

  public InsufficientStockForProductException() {
    super("Insufficient stock for product");
  }
}
