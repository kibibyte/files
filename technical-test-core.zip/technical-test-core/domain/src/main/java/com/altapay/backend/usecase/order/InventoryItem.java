package com.altapay.backend.usecase.order;

import static com.altapay.backend.utils.ValidationUtils.notLessThanZero;
import static com.altapay.backend.utils.ValidationUtils.notNull;

import lombok.Value;

@Value
public class InventoryItem {

  Product product;
  int stock;

  public InventoryItem(Product product, int stock) {
    notNull(product, "Product cannot be null");
    notLessThanZero(stock, "Stock must be not less than 0");

    this.product = product;
    this.stock = stock;
  }
}
