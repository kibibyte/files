package com.altapay.backend.usecase.order;

import com.altapay.backend.usecase.order.exceptions.MerchantApiServiceException;

interface MerchantApiClient {

  CapturePaymentResult capturePayment(Order order) throws MerchantApiServiceException;

  CancelPaymentResult cancelPayment(Order order) throws MerchantApiServiceException;

  class CancelPaymentResult {

  }

  class CapturePaymentResult {

  }
}
