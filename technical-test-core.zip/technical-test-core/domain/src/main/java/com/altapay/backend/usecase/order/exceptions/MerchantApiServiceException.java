package com.altapay.backend.usecase.order.exceptions;

import com.altapay.backend.exceptions.DomainException;

public class MerchantApiServiceException extends DomainException {

  public MerchantApiServiceException(String message) {
    super(message);
  }
}
