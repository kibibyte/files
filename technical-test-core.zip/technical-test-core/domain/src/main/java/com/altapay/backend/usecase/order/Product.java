package com.altapay.backend.usecase.order;

import static com.altapay.backend.utils.ValidationUtils.notBlank;

import lombok.Value;

@Value
public class Product {

  String id;
  String name;

  public Product(String id, String name) {
    notBlank(id, "Invalid productId");
    notBlank(name, "Invalid product name");

    this.id = id;
    this.name = name;
  }
}
