package com.altapay.backend.utils;

import java.util.List;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class ValidationUtils {

  public static void notBlank(String str, String msg) {
    if (str == null || str.isBlank()) {
      throw new IllegalArgumentException(msg);
    }
  }

  public static void notEmpty(List list, String msg) {
    if (list.isEmpty()) {
      throw new IllegalArgumentException(msg);
    }
  }

  public static void notNull(Object object, String msg) {
    if (object == null) {
      throw new IllegalArgumentException(msg);
    }
  }

  public static void greaterThanZero(Integer value, String msg) {
    if (value <= 0) {
      throw new IllegalArgumentException(msg);
    }
  }

  public static void notLessThanZero(Integer value, String msg) {
    if (value < 0) {
      throw new IllegalArgumentException(msg);
    }
  }
}
