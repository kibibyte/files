package com.altapay.backend.usecase.order;

import java.util.Optional;

public interface OrderRepository {

  Optional<Order> find(String orderId);
}
