package com.altapay.backend.usecase.order.capture;

import com.altapay.backend.exceptions.EntityNotFoundException;
import com.altapay.backend.usecase.order.InventoryService;
import com.altapay.backend.usecase.order.MerchantService;
import com.altapay.backend.usecase.order.Order;
import com.altapay.backend.usecase.order.OrderRepository;
import com.altapay.backend.usecase.order.exceptions.InsufficientStockForProductException;
import com.altapay.backend.usecase.order.exceptions.OrderException;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class CaptureOrderService {

  private final OrderRepository orderRepository;
  private final InventoryService inventoryService;
  private final MerchantService merchantService;

  public void captureOrder(String orderId) {
    Order order = getOrder(orderId);

    if (!isAllOrderedProductsInStock(order)) {
      throw new InsufficientStockForProductException();
    }

    try {
      merchantService.capturePayment(order);
      takeFromInventory(order);
    } catch (Exception e) {
      throw new OrderException("Order cannot be captured");
    }
  }

  private void takeFromInventory(Order order) {
    order.getOrderLines().forEach(line -> inventoryService.take(line.getProduct(), line.getQuantity()));
  }

  private boolean isAllOrderedProductsInStock(Order order) {
    return order.getOrderLines().stream()
        .allMatch(line -> inventoryService.checkStock(line.getProduct(), line.getQuantity()));
  }

  private Order getOrder(String orderId) {
    return orderRepository.find(orderId).orElseThrow(() -> new EntityNotFoundException("Order not found"));
  }
}
