package com.altapay.backend.usecase.order;

import com.altapay.backend.usecase.order.MerchantApiClient.CancelPaymentResult;
import com.altapay.backend.usecase.order.MerchantApiClient.CapturePaymentResult;
import com.altapay.backend.usecase.order.exceptions.MerchantApiServiceException;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class MerchantService {

  private final MerchantApiClient merchantApiClient;

  public CapturePaymentResult capturePayment(Order order) throws MerchantApiServiceException {
    // We don't need to implement this, write the rest of the code as if this has been implemented by use of the httpUtil and the xpathUtil
    return null;
  }

  public CancelPaymentResult cancelPayment(Order order) throws MerchantApiServiceException {
    // We don't need to implement this, write the rest of the code as if this has been implemented by use of the httpUtil and the xpathUtil
    return null;
  }
}
