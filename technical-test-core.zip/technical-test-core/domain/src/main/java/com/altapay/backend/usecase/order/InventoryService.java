package com.altapay.backend.usecase.order;

import com.altapay.backend.exceptions.EntityNotFoundException;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class InventoryService {

  private InventoryRepository repository;

  public boolean checkStock(Product product, int quantity) {
    return repository.find(product.getId())
        .filter(item -> item.getStock() >= quantity)
        .isPresent();
  }

  public void take(Product product, int quantity) {
    InventoryItem inventoryItem = getInventoryItem(product);

    InventoryItem updatedInventoryItem = new InventoryItem(
        inventoryItem.getProduct(),
        inventoryItem.getStock() - quantity
    );

    repository.update(updatedInventoryItem);
  }

  public void release(Product product, int quantity) {
    InventoryItem inventoryItem = getInventoryItem(product);

    InventoryItem updatedInventoryItem = new InventoryItem(
        inventoryItem.getProduct(),
        inventoryItem.getStock() + quantity
    );

    repository.update(updatedInventoryItem);
  }

  private InventoryItem getInventoryItem(Product product) {
    return repository.find(product.getId())
        .orElseThrow(() -> new EntityNotFoundException("Product not found"));
  }
}
