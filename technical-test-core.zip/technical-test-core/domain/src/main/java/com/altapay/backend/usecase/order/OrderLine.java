package com.altapay.backend.usecase.order;

import static com.altapay.backend.utils.ValidationUtils.greaterThanZero;
import static com.altapay.backend.utils.ValidationUtils.notNull;

import lombok.Value;

@Value
public class OrderLine {

  Product product;
  int quantity;

  public OrderLine(Product product, int quantity) {
    notNull(product, "Product cannot be null");
    greaterThanZero(quantity, "Product quantity must be greater than 0");

    this.product = product;
    this.quantity = quantity;
  }
}
