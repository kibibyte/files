package com.altapay.backend.usecase.order.exceptions;

import com.altapay.backend.exceptions.DomainException;

public class OrderException extends DomainException {

  public OrderException(String message) {
    super(message);
  }
}
