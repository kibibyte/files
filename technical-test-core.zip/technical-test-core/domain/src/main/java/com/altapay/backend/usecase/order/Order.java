package com.altapay.backend.usecase.order;

import static com.altapay.backend.utils.ValidationUtils.notBlank;
import static com.altapay.backend.utils.ValidationUtils.notEmpty;

import java.util.List;

import lombok.Value;

@Value
public class Order {

  String id;
  String paymentId;
  List<OrderLine> orderLines;

  public Order(String id, String paymentId, List<OrderLine> orderLines) {
    notBlank(id, "Invalid orderId");
    notBlank(paymentId, "Invalid paymentId");
    notEmpty(orderLines, "Order lines cannot be empty");

    this.id = id;
    this.paymentId = paymentId;
    this.orderLines = orderLines;
  }
}
