package com.altapay.backend.usecase.order.cancel;

import lombok.AllArgsConstructor;

import static com.altapay.backend.utils.ValidationUtils.notBlank;

@AllArgsConstructor
public class CancelOrderController {

    private CancelOrderService service;

    public void cancelOrder(String orderId) {
        notBlank(orderId, "Invalid orderId");
        service.cancelOrder(orderId);
    }
}
