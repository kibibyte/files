package com.altapay.backend.ioc;

import java.util.HashMap;

import com.altapay.backend.usecase.order.InventoryRepository;
import com.altapay.backend.usecase.order.InventoryRepositoryStub;
import com.altapay.backend.usecase.order.InventoryService;
import com.altapay.backend.usecase.order.MerchantApiClientStub;
import com.altapay.backend.usecase.order.MerchantService;
import com.altapay.backend.usecase.order.OrderRepository;
import com.altapay.backend.usecase.order.OrderRepositoryStub;
import com.altapay.backend.usecase.order.cancel.CancelOrderController;
import com.altapay.backend.usecase.order.cancel.CancelOrderService;
import com.altapay.backend.usecase.order.capture.CaptureOrderController;
import com.altapay.backend.usecase.order.capture.CaptureOrderService;

public class BackendContainer {

  private static final HashMap<String, Object> singleInstances = new HashMap<>();

  public CancelOrderController cancelOrderController() {
    return new CancelOrderController(cancelOrderService());
  }

  public CaptureOrderController captureOrderController() {
    return new CaptureOrderController(captureOrderService());
  }

  public CancelOrderService cancelOrderService() {
    return new CancelOrderService(
        shopOrderRepository(),
        inventoryService(),
        merchantService()
    );
  }

  public CaptureOrderService captureOrderService() {
    return new CaptureOrderService(
        shopOrderRepository(),
        inventoryService(),
        merchantService()
    );
  }

  public InventoryService inventoryService() {
    return new InventoryService(inventoryRepository());
  }

  public MerchantService merchantService() {
    return new MerchantService(merchantApiClient());
  }

  public OrderRepository shopOrderRepository() {
    String key = OrderRepository.class.getName();
    if (singleInstances.containsKey(OrderRepository.class.getName())) {
      return (OrderRepository) singleInstances.get(key);
    } else {
      OrderRepositoryStub orderRepository = new OrderRepositoryStub();
      singleInstances.put(key, new OrderRepositoryStub());

      return orderRepository;
    }
  }

  public MerchantApiClientStub merchantApiClient() {
    return new MerchantApiClientStub();
  }

  public InventoryRepository inventoryRepository() {
    return new InventoryRepositoryStub();
  }
}
