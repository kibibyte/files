package com.altapay.backend.usecase.order.capture;

import lombok.AllArgsConstructor;

import static com.altapay.backend.utils.ValidationUtils.notBlank;

@AllArgsConstructor
public class CaptureOrderController {

    private CaptureOrderService orderService;

    public void captureOrder(String orderId) {
        notBlank(orderId, "Invalid orderId");
        orderService.captureOrder(orderId);
    }
}
