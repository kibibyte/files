package com.altapay.backend.usecase.order.cancel;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class CancelOrderControllerTests {

  private static final String VALID_ORDER_ID = "Some order id";
  private static final String INVALID_ORDER_ID = " ";

  @Mock
  private CancelOrderService cancelOrderService;

  // The object to be tested
  private CancelOrderController controller;

  @BeforeEach
  public void setup() {
    MockitoAnnotations.openMocks(this);

    controller = new CancelOrderController(cancelOrderService);
  }

  @Test
  public void shouldCancelOrder() {
    //when
    controller.cancelOrder(VALID_ORDER_ID);

    //then
    verify(cancelOrderService, times(1)).cancelOrder(VALID_ORDER_ID);
  }

  @Test
  public void shouldNotCancelOrder_whenOrderOrderIdIsInvalid() {
    //when
    assertThrows(IllegalArgumentException.class, () -> controller.cancelOrder(INVALID_ORDER_ID));

    //then
    verify(cancelOrderService, times(0)).cancelOrder(INVALID_ORDER_ID);
  }
}
