package com.altapay.backend.usecase.order.capture;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class CaptureOrderControllerTests {

  private static final String VALID_ORDER_ID = "Some order id";
  private static final String INVALID_ORDER_ID = " ";

  @Mock
  private CaptureOrderService service;

  // The object to be tested
  private CaptureOrderController controller;

  @BeforeEach
  public void setup() {
    MockitoAnnotations.openMocks(this);

    controller = new CaptureOrderController(service);
  }

  @Test
  public void shouldCaptureOrder() {
    //when
    controller.captureOrder(VALID_ORDER_ID);

    //then
    verify(service, times(1)).captureOrder(VALID_ORDER_ID);
  }

  @Test
  public void shouldNotCaptureOrder_whenOrderIdIsInvalid() {
    //when
    assertThrows(IllegalArgumentException.class, () -> controller.captureOrder(INVALID_ORDER_ID));

    //then
    verify(service, times(0)).captureOrder(INVALID_ORDER_ID);
  }
}
